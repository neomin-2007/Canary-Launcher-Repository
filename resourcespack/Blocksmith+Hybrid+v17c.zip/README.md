The Blocksmith Hybrid resource pack 
 
 
License:

You may:
Use this texture pack in youtube videos and/or other media, but please provide a link to my minecraftforum.net post: http://www.minecraftforum.net/topic/1778085- or http://www.bit.ly/blocksmith
Edit any part of this pack for your personal use, just don't distribute it.
Use this pack as your server's resource pack, or use parts of it in your server's resource pack as long as you give me credit.
Post/share any of the download links on the forum post, just link to the forum post as well.

You may not:
Distribute this pack or any part of it with a link other than one of mine. (Except as stated above)
Use any of these textures in another resource pack or remix pack.

With the exception of:
Exclusive permission from me, blocksmithed (http://www.minecraftforum.net/user/1931422-blocksmithed/).

Also:
Please don't post a direct download link. Instead use a bit.ly one from under "Version History/Alternate download links." They work just as well, and anyone can track download stats by adding a "+" after the bitly url.


Original Minecraft textures belong to Mojang.